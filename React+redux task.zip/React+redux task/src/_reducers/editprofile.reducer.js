import { userConstants } from '../_constants';

export function editprofile(state = {}, action) {
  switch (action.type) {
    case userConstants.GET_BY_ID_REQUEST:
      return {
        updating: true
      };
    case userConstants.GET_BY_ID_SUCCESS:
      return {
        items: action.user
      };
    case userConstants.GET_BY_ID_FAILURE:
      return {
        error: action.error
      };
    case userConstants.UPDATE_REQUEST:
      return { user: action.user, updating: true };
    case userConstants.UPDATE_SUCCESS:
      return { user: action.user, updating: true };
    case userConstants.UPDATE_FAILURE:
      return {};
    default:
      return state
  }
}