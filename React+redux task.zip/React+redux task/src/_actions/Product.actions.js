import { userConstants,productConstants } from '../_constants';
import { userService,productService } from '../_services';
import { alertActions } from './';
import { history } from '../_helpers';

export const productActions = {
    addProduct,
    getAllProducts,
    deletepost:_deletepost
};
function addProduct(product) {
    return dispatch => {
        dispatch(request(product));

        productService.addProduct(product)
            .then(
                product => {
                    dispatch(success());
                    history.push('/');
                    dispatch(alertActions.success('Product Added successfully'));
                },
                error => {
                    dispatch(failure(error));
                    dispatch(alertActions.error(error));
                }
            );
    };

    function request(product) { return { type: productConstants.REGISTER_REQUEST, product } }
    function success(product) { return { type: productConstants.REGISTER_SUCCESS, product } }
    function failure(error) { return { type: productConstants.REGISTER_FAILURE, error } }
}

function getAllProducts() {
    
    return dispatch => {
        dispatch(request());

        productService.getAllProducts()
            .then(
                products => dispatch(success(products)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: productConstants.GETALL_REQUEST } }
    function success(products) { return { type: productConstants.GETALL_SUCCESS, products } }
    function failure(error) { return { type: productConstants.GETALL_FAILURE, error } }
}
function _deletepost(id) {
    return dispatch => {
        dispatch(request(id));

        productService.deletepost(id)
            .then(
                product => {
                    dispatch(success(id));
                },
                error => {
                    dispatch(failure(id, error));
                }
            );
    };

    function request(id) { return { type: productConstants.DELETE_REQUEST, id } }
    function success(id) { return { type: productConstants.DELETE_SUCCESS, id } }
    function failure(id, error) { return { type: productConstants.DELETE_FAILURE, id, error } }
}
