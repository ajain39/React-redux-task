import { authHeader } from '../_helpers';

export const productService = {
    addProduct,
    getAllProducts,
    deletepost
};
function addProduct(product) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
    };

    return fetch('/product/add', requestOptions).then(handleResponse);
}
function getAllProducts() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch('/products', requestOptions).then(handleResponse);
}
function deletepost(id) {
    const requestOptions = {
        method: 'DELETE',
        headers: authHeader()
    };

    return fetch('/products/' + id, requestOptions).then(handleResponse);;
}
function handleResponse(response) {
    if (!response.ok) {
        return Promise.reject(response.statusText);
    }

    return response.json();
}