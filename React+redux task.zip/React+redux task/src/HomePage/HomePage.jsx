import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { myFunction } from '../HomePage/index';
import SearchInput, { createFilter } from 'react-search-input';
import { userActions, productActions } from '../_actions';
import ReactImageMagnify from 'react-image-magnify';
import { Pagination } from '../Pagination';

class HomePage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTerm: '',
      products: [],
      pageOfItems: [],
      pageOfImages: []
    }
    this.searchUpdated = this.searchUpdated.bind(this);
    this.handleInfiniteLoad = this.handleInfiniteLoad.bind(this);
    this.onChangePage = this.onChangePage.bind(this);
    this.onChangeImage = this.onChangeImage.bind(this);
    this.cardGrid = this.cardGrid.bind(this);
    this.handleDeletePost=this.handleDeletePost.bind(this);
    this.ImageProtection=this.ImageProtection.bind(this);
    
  }
  componentDidMount() {
    this.props.dispatch(productActions.getAllProducts());
    this.handleInfiniteLoad(30);
    this.cardGrid();
    this.ImageProtection();
  }

  cardGrid() {
    var ANIMATION_SPEED = 300
    var SCROLL_SPEED = 200
    var THIS=this;
    // Adjust card-details position relative to grid based on changing number of
    // columns per row.
    var updateCardDetailsPos = function () {
      var w = $(window).width
      var cardDetails = $('.card-details')
      var cardDetailsSize = cardDetails.length

      cardDetails.each(function (i) {
        var cardsPerRow = $(this).css('grid-column-end') - 1
        var row = Math.floor(i / cardsPerRow)
        var gridRowStyle = (row + 2) + ' / ' + (row + 3)

        $(this).css('grid-row', gridRowStyle)
      })
    }

    var handleResize = function () {
      updateCardDetailsPos()
    }

    var scrollToButton = function (button) {
      $('html, body').animate({
        scrollTop: button.offset().top
      }, SCROLL_SPEED)
    }

    // Clicking a card should toggle its corresponding details block open (and
    // close other details blocks that might already be open).
    var handleCardClick = function () {
      var exampleImages = [...Array(15).keys()].map(i => ("/images/Harley.jpg"));
      THIS.setState({exampleImages:exampleImages });
      var clickedCard = $(this)
      // var clickedCardIcon = clickedCard.find('.card-icon').first()
      var clickedCardIcon = clickedCard.first()
      var cards = $('.card-icon')
      var cardsSize = cards.length
      var i = cards.index(this)
      var clickedDetails = $('.card-details:eq(' + i + ')')
      var openCard = $('.card.open').first()
      var openDetails = $('.card-details.open').first()
      var sameRowDetails = clickedDetails.css('grid-row') === openDetails.css('grid-row')
      // var clickClose = clickedCard.hasClass('open')
      var clickClose = clickedCard.hasClass('card-close')

      // set all cards to "closed"
      $('.card').removeClass('open')
      $('.card .card-icon').removeClass('card-close')
      $('.card-details').removeClass('open')

      if (!clickClose) {
        
        clickedCardIcon.addClass('card-close')
        clickedCard.addClass('open')
        clickedDetails.addClass('open')
      }

      // close/open details (use "fade" if on same row as existing open details,
      // otherwise, use "slide").
      if (clickClose) {
        clickedDetails.slideToggle(ANIMATION_SPEED)
        scrollToButton(clickedCard)
      } else if (!clickClose && sameRowDetails) {
        clickedDetails.fadeIn(ANIMATION_SPEED)
        openDetails.fadeOut(ANIMATION_SPEED)
      } else {
        openDetails.slideUp(ANIMATION_SPEED).promise().done(function () {
          clickedDetails.slideToggle(ANIMATION_SPEED)
          scrollToButton(clickedCard)
        })
      }
    }

    // Wait until markup and styles have finished rendering before intializing
    // JS resizing (setTimeout(0) forces wait until next available draw cycle).
    $(document).ready(function () {
      setTimeout(function () {
        $('.card-icon').click(handleCardClick)
        $(window).resize(handleResize)
        handleResize()
      }, 500)
    })
  }
  handleInfiniteLoad(Qnt) {
    var exampleItems = [...Array(Qnt).keys()].map(i => ({
      id: (i + 1),
      postheading: "package" + (i + 1),
      postData: Qnt,
      postDesc: i + "Lorem ipsum dolor "
    }));
    this.setState({ exampleItems: exampleItems});
  }
  handleDeletePost(id) {
    this.props.dispatch(productActions.deletepost(id));
     }
  searchUpdated(term) {
    this.setState({ searchTerm: term })
  }
  onChangePage(pageOfItems) {
    this.setState({ pageOfItems: pageOfItems });

  }
  onChangeImage(pageOfItems) {
    setTimeout(()=> {
    this.setState({ pageOfImages: pageOfItems });      
    }, 1000)
  }
  ImageProtection(){
    window.onload = function() {

        var imageObj = new Image();
        imageObj.src = "/images/avatar_hat.jpg";
        /* Create a canvas Element*/
        var dynamicCanvas = document.createElement("canvas");
        var dynamicContext = dynamicCanvas.getContext("2d");
        dynamicCanvas.height="400";
        dynamicCanvas.width="400";

        var canvas = document.getElementById("myCanvas");
        var context = canvas.getContext("2d");

        imageObj.onload = function() {
          dynamicContext.drawImage(imageObj, 0, 0);
          context=context.drawImage(dynamicCanvas,-120,-25);
          console.log(canvas);
          console.log(canvas.toDataURL())
          
        };
        document.addEventListener('contextmenu', event => event.preventDefault());

      };
  }
  render() {
    var THIS=this;
    var imgArr=["/images/icons/dashboard.png",
    "/images/icons/packages.png",
    "/images/icons/trips.png",
    "/images/icons/travel_posts.png",
    "/images/icons/message.png",
    "/images/icons/contacts.png",
    "/images/icons/Profile_setting.png",
    "/images/icons/Profile_setting.png",];
    const { user, users, products } = this.props;
    const KEYS_TO_PRODFILTERS = ['ProductName', 'ProductID'];
    var filteredProducts = [];
    if (products && products.length) {
      filteredProducts = products.filter(createFilter(this.state.searchTerm, KEYS_TO_PRODFILTERS))
    }
    return (
      <div className="container-fluid">
        <div className="w3-top">
          <div className="w3-bar w3-black w3-card">
            <Link to="/" className="w3-bar-item w3-button w3-padding-large">HOME</Link>
            <Link to="/edit" className="w3-bar-item w3-button w3-padding-large ">EDIT PROFILE</Link>
            <Link to="/login" className="w3-padding-large w3-hover-red  w3-right">Logout</Link>
          </div>
        </div>
        <div id="navDemo" className="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style={{ marginTop: "46px" }}>
          <Link to="/" className="w3-bar-item w3-button w3-padding-large">HOME</Link>
          <Link to="/edit" className="w3-bar-item w3-button w3-padding-large">EDIT PROFILE</Link>
        </div>
        <div >
          <div className="col-xs-12 col-md-12 col-lg-12" style={{ marginTop: "50px", backgroundColor:'rgb(234, 239, 245)' }} >
            <div className="col-md-3">
              <div className="w3-white w3-text-grey w3-card-4">
                <div className="w3-display-container" style={{ margin: "0px auto", textAlign: "center" }}>
               
                <canvas id="myCanvas" width="240" height="240" style={{"border":"1px solid #d3d3d3"}}>
                </canvas>
                <div id="img">
                </div>
                  <img src="/images/avatar_hat.jpg" style={{ width: "100px", height: "100px", borderRadius: "100%", margin: "20px" }} alt="Avatar" />
                  <div className="w3-container w3-text-black" style={{ textAlign: "center" }}>
                    <p><i className="fa fa-circle fa-fw w3-large " style={user.status == 'busy' ? { color: 'red' } : user.status == 'away' ? { color: 'orange' } : { color: 'green' }}></i>{user.firstName + ' ' + user.lastName}</p>
                  </div>
                  <hr className="divider" />
                </div>
                <div className="w3-container portfolio-items">
                  <p> <span className="img-sec"><img src="/images/icons/dashboard.png" /></span>Dashboard</p>
                  <p><span className="img-sec"><img src="/images/icons/packages.png" /></span>Packages</p>
                  <p><span className="img-sec"><img src="/images/icons/trips.png" /></span>Trips</p>
                  <p><span className="img-sec"><img src="/images/icons/travel_posts.png" /></span>Travel Posts</p>
                  <p><span className="img-sec"><img src="/images/icons/message.png" /></span>Messages</p>
                  <p><span className="img-sec"><img src="/images/icons/contacts.png" /></span>Contracts</p>
                  <p><span className="img-sec"><img src="/images/icons/Profile_setting.png" /></span><Link to="/edit" className="anchor-color" >Profile Setting</Link></p>
                  <p><span className="img-sec"><img src="/images/icons/Profile_setting.png" /></span><Link to="/addproduct" className="anchor-color" >Add Post</Link></p>
                </div>
              </div><br />
            </div>
            <div className="col-md-9">
              <div className="w3-container w3-card w3-white w3-margin-bottom" >
                <h2 className="w3-text-grey text-align-center">Dashboard</h2>
                <hr className="divider" />
                <SearchInput className="search-input" placeholder="Search for card..." onChange={this.searchUpdated} />
                <div className="card-grid">
                  {filteredProducts && filteredProducts.length ? filteredProducts.map((obj, ind) => {
                    return [<div className="card" key={"card" + ind}>
                      <div className="card-button">
                        <div className="card-text"><span >
                          {obj.ProductName}
                        </span>
                          <p >total packages: {obj.productData}</p>
                          <p className="card-icon">View all {obj.ProductName}</p>
                        </div>
                        <span className="img-sec-card"><img src={imgArr[ind]} /></span>
                        <i className="fa fa-trash trash-icon" aria-hidden="true" onClick={()=>THIS.handleDeletePost(obj.id)} ></i>
                      </div>
                    </div>, <div className="card-details"  key={"card-details" + ind}>
                      <div className="card-details-body">
                        {this.state.pageOfItems && ind == 1 && this.state.pageOfItems.map((item, i) =>
                          <div className="w3-container" key={'Posts' + i}>
                            <span className="w3-opacity"><b>{item.postheading}</b></span>
                          </div>
                        )}
                    {ind == 0 && <div className="imgfluid col-lg-12" >   {this.state.pageOfImages && this.state.pageOfImages.map((imgsrc,imgkey)=><div className="innerfluid col-lg-3" key={"img"+imgkey}><ReactImageMagnify {...{
                    smallImage: {
                      srcSet:this.state.pageOfImages.join(', '),
                      alt: 'Wristwatch by Ted Baker London',
                      isFluidWidth: true,
                      src: imgsrc,
                      sizes: '(max-width: 100px) 100vw, (max-width: 100px) 30vw, 360px'
                    },
                    largeImage: {
                      src: imgsrc,
                      width: 1200,
                      height: 1800
                    },
                    enlargedImageContainerClassName:"largeimagepreview"
                  }} /></div>)}</div>}
                      </div>
                      {ind == 1 ? <Pagination items={this.state.exampleItems} onChangePage={this.onChangePage} /> :ind == 0? <Pagination items={this.state.exampleImages} onChangePage={this.onChangeImage} />:""}
                      
                    </div>];
                  }) : ""}
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

    );
  }
}

function mapStateToProps(state) {
  const { users, authentication, products } = state;
  const { user } = authentication;
  return {
    user,
    users,
    products
  };
}

const connectedHomePage = connect(mapStateToProps)(HomePage);
export { connectedHomePage as HomePage };